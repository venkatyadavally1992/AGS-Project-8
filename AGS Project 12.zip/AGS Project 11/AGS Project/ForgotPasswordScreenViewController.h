//
//  ForgotPasswordScreenViewController.h
//  AGS Project
//
//  Created by venkat on 7/30/16.
//  Copyright © 2016 venkat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "sqlite3.h"

@interface ForgotPasswordScreenViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIButton *retriveButton;
@property (strong, nonatomic) IBOutlet UITextField *toRetrivePhoneNumber;
@property (strong, nonatomic) IBOutlet UITextField *toRetriveEmail;
@property (strong, nonatomic) IBOutlet UILabel *labelPassordNotofication;

@property (strong, nonatomic) IBOutlet UILabel *passwordField;
@property (strong, nonatomic) IBOutlet UITextField *toRetriveFullName;
-(IBAction)retrivePassword:(id)sender;
@end
