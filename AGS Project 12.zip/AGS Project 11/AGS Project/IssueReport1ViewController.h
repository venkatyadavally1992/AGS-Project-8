//
//  IssueReport1ViewController.h
//  AGS Project
//
//  Created by venkat on 7/20/16.
//  Copyright © 2016 venkat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginPageViewController.h"

@interface IssueReport1ViewController : UIViewController
-(IBAction)IssueDescriptionAlert:(id)sender;
-(IBAction)IssueDescriptionAlert2:(id)sender;
-(IBAction)IssueCameralert:(id)sender;

-(IBAction)IssueLocationAlert:(id)sender;
@end
