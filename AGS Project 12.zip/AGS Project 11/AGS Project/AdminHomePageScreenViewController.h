//
//  AdminHomePageScreenViewController.h
//  AGS Project
//
//  Created by venkat on 7/30/16.
//  Copyright © 2016 venkat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AdminHomePageScreenViewController : UIViewController

@end
